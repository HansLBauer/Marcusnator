/**
 * Marcusnator Pro Athlete 2.0 By Dr. Hans
 * Backend Google Apps Script conectado à planilha oficial:
 * https://docs.google.com/spreadsheets/d/1lM9dHsrdv59n_HkY5Oa75UBzbabNDUfdCvgOMgCWxxc/edit
 *
 * COMO IMPLANTAR:
 * 1. Abra a planilha acima > Extensões > Apps Script.
 * 2. Cole este código inteiro substituindo o conteúdo padrão e salve.
 * 3. Clique em "Implantar" > "Nova implantação" > Tipo: "App da Web".
 * 4. Executar como: "Eu" | Quem pode acessar: "Qualquer pessoa".
 * 5. Copie a URL gerada (termina em /exec) e cole nas configurações do WebApp.
 */

const SPREADSHEET_ID = '1lM9dHsrdv59n_HkY5Oa75UBzbabNDUfdCvgOMgCWxxc';

const SCHEMAS = {
  Perfis: [
    'ID_Perfil', 'Nome_Completo', 'Senha_Hash', 'Pergunta_Recuperacao',
    'Resposta_Recuperacao_Hash', 'Criado_Em', 'Atualizado_Em'
  ],
  Anamnese_Metas: [
    'ID_Perfil', 'Altura_m', 'Idade', 'Sexo', 'Peso_Atual_kg', 'Peso_Meta_kg',
    'Data_Alvo', 'Medidas_Corporais_JSON', 'Meta_Kcal', 'Meta_Proteina_g',
    'Data_Inicio', 'Horario_Acordar', 'Horario_Dormir', 'Treinos_Semana',
    'Horario_Trabalho', 'Modalidade_Trabalho', 'O_Que_Come_Hoje',
    'Comidas_Nao_Cortar', 'Comidas_Nao_Come', 'Tempo_Cozinhar',
    'Frequencia_Delivery', 'Suplementos', 'Agua_ml_kg', 'Agua_Meta_ml',
    'Config_Notificacoes_JSON', 'Atualizado_Em'
  ],
  Cardapio: [
    'ID_Registro', 'ID_Perfil', 'Data_ISO', 'Refeicao_Nome', 'Horario',
    'Itens_JSON', 'Kcal_Total', 'Proteina_Total', 'Status', 'Atualizado_Em'
  ],
  Diario: [
    'ID_Registro', 'ID_Perfil', 'Data_ISO', 'Horario', 'Refeicao',
    'Descricao', 'Kcal', 'Proteina_g', 'Delivery', 'Estimado_IA', 'Criado_Em'
  ],
  Pesagens_Medidas: [
    'ID_Registro', 'ID_Perfil', 'Data_ISO', 'Peso_kg', 'Cintura_cm',
    'Outras_Medidas_JSON', 'Observacao', 'Criado_Em'
  ],
  Treinos: [
    'ID_Registro', 'ID_Perfil', 'Data_ISO', 'Atividade', 'Minutos',
    'Intensidade', 'Criado_Em'
  ],
  Plano_Custom: [
    'ID_Perfil', 'Semana_Treinos_JSON', 'Proximos_Eventos_JSON',
    'Cardapio_Base_JSON', 'Trocas_JSON', 'Regras_FDS_JSON',
    'Regras_Dia_JSON', 'Marmitas_JSON', 'Guia_Delivery_JSON', 'Atualizado_Em'
  ],
  EFCA_Resultados: [
    'ID_Registro', 'ID_Perfil', 'Data_ISO', 'Pontuacao_Total',
    'Fenotipos_JSON', 'Fenotipo_Dominante', 'Respostas_JSON'
  ]
};

function getDb() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  Object.keys(SCHEMAS).forEach(function(tabName) {
    let sh = ss.getSheetByName(tabName);
    if (!sh) {
      sh = ss.insertSheet(tabName);
    }
    const headers = SCHEMAS[tabName];
    if (sh.getLastRow() === 0) {
      sh.getRange(1, 1, 1, headers.length).setValues([headers]);
      sh.setFrozenRows(1);
    }
  });
  return ss;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sheetToObjects(sh) {
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  const rows = [];
  for (let i = 1; i < values.length; i++) {
    const obj = {};
    for (let j = 0; j < headers.length; j++) {
      obj[headers[j]] = values[i][j];
    }
    rows.push(obj);
  }
  return rows;
}

function replaceRowsByProfile(sh, tabName, profileId, records) {
  const headers = SCHEMAS[tabName];
  const values = sh.getDataRange().getValues();
  const profileColIdx = headers.indexOf('ID_Perfil');
  const kept = [headers];
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][profileColIdx]) !== String(profileId)) {
      kept.push(values[i]);
    }
  }
  (records || []).forEach(function(rec) {
    const row = headers.map(function(h) {
      const val = rec[h];
      if (val === undefined || val === null) return '';
      if (typeof val === 'object') return JSON.stringify(val);
      return val;
    });
    kept.push(row);
  });
  sh.clearContents();
  if (kept.length > 0) {
    sh.getRange(1, 1, kept.length, headers.length).setValues(kept);
  }
}

function doGet(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) || 'ping';
    const ss = getDb();

    if (action === 'ping') {
      const perfis = sheetToObjects(ss.getSheetByName('Perfis'));
      return jsonOut({
        ok: true,
        app: 'Marcusnator Pro Athlete 2.0 By Dr. Hans',
        spreadsheet: ss.getName(),
        profilesCount: perfis.length
      });
    }

    if (action === 'list_profiles') {
      const perfis = sheetToObjects(ss.getSheetByName('Perfis'));
      return jsonOut({ ok: true, profiles: perfis });
    }

    if (action === 'load_profile_bundle') {
      const pid = e.parameter.profileId;
      if (!pid) return jsonOut({ ok: false, error: 'profileId ausente' });
      const filterPid = function(arr) {
        return arr.filter(function(r) { return String(r.ID_Perfil) === String(pid); });
      };
      return jsonOut({
        ok: true,
        perfil: filterPid(sheetToObjects(ss.getSheetByName('Perfis')))[0] || null,
        anamnese: filterPid(sheetToObjects(ss.getSheetByName('Anamnese_Metas')))[0] || null,
        cardapio: filterPid(sheetToObjects(ss.getSheetByName('Cardapio'))),
        diario: filterPid(sheetToObjects(ss.getSheetByName('Diario'))),
        pesagens: filterPid(sheetToObjects(ss.getSheetByName('Pesagens_Medidas'))),
        treinos: filterPid(sheetToObjects(ss.getSheetByName('Treinos'))),
        plano: filterPid(sheetToObjects(ss.getSheetByName('Plano_Custom')))[0] || null,
        efca: filterPid(sheetToObjects(ss.getSheetByName('EFCA_Resultados')))
      });
    }

    return jsonOut({ ok: false, error: 'Ação desconhecida: ' + action });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    const action = body.action || 'sync_profile_bundle';
    const ss = getDb();

    if (action === 'sync_profile_bundle') {
      const pid = body.profileId;
      if (!pid) return jsonOut({ ok: false, error: 'profileId obrigatório' });

      if (body.perfil) {
        replaceRowsByProfile(ss.getSheetByName('Perfis'), 'Perfis', pid, [body.perfil]);
      }
      if (body.anamnese) {
        replaceRowsByProfile(ss.getSheetByName('Anamnese_Metas'), 'Anamnese_Metas', pid, [body.anamnese]);
      }
      if (Array.isArray(body.cardapio)) {
        replaceRowsByProfile(ss.getSheetByName('Cardapio'), 'Cardapio', pid, body.cardapio);
      }
      if (Array.isArray(body.diario)) {
        replaceRowsByProfile(ss.getSheetByName('Diario'), 'Diario', pid, body.diario);
      }
      if (Array.isArray(body.pesagens)) {
        replaceRowsByProfile(ss.getSheetByName('Pesagens_Medidas'), 'Pesagens_Medidas', pid, body.pesagens);
      }
      if (Array.isArray(body.treinos)) {
        replaceRowsByProfile(ss.getSheetByName('Treinos'), 'Treinos', pid, body.treinos);
      }
      if (body.plano) {
        replaceRowsByProfile(ss.getSheetByName('Plano_Custom'), 'Plano_Custom', pid, [body.plano]);
      }
      if (Array.isArray(body.efca)) {
        replaceRowsByProfile(ss.getSheetByName('EFCA_Resultados'), 'EFCA_Resultados', pid, body.efca);
      }

      return jsonOut({ ok: true, syncedAt: new Date().toISOString() });
    }

    if (action === 'update_password') {
      const pid = body.profileId;
      const newHash = body.senhaHash;
      const sh = ss.getSheetByName('Perfis');
      const values = sh.getDataRange().getValues();
      for (let i = 1; i < values.length; i++) {
        if (String(values[i][0]) === String(pid)) {
          sh.getRange(i + 1, 3).setValue(newHash);
          sh.getRange(i + 1, 7).setValue(new Date().toISOString());
          break;
        }
      }
      return jsonOut({ ok: true });
    }

    return jsonOut({ ok: false, error: 'Ação POST desconhecida' });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}
